# Tata Sky m3u generator web app
This project is totally based on CodeCrafters API.

A react web app to generate an m3u playlist for the channels Available on Tata Sky.

## Update
Converted to a single repo to make it a one click deploy on vercel as a lot of you non-technical people were facing difficulties while deploying.
## Deploy on vercel and access from anywhere (Easy)
1) Click the button below to deploy.<br>
<a href="https://vercel.com/new/clone?repository-url=https://github.com/lalitjoshi06/Tplay_All.git"><img src="https://vercel.com/button" alt="Deploy"/></a><br>
You will need an account on Vercel. It's free!

<a href="https://render.com/deploy?repo=https://github.com/lalitjoshi06/Tplay_All.git"><img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy"/></a><br>
You will need an account on Render. It's free!
Enjoy!
## Run locally (You need a little bit of git and npm knowledge)
1) Clone this repo.
2) Open cmd / terminal and type the below commands one by one.<br>
a) npm install<br>
b) npm run dev
3) Enjoy!

## Note : **use this playlist on OTT Navigator and set to reload data to 2 to 4 hours, Bcz key expires in 4 to 24 hours for most of channels.           

This script is only for educational purpose and not for sale. 

##Special thanks to CodeCrafters for their API.##

